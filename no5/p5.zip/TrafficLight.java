package no5;

import java.util.concurrent.Semaphore;
import java.util.Random;


public class TrafficLight {
	static int NorthernBound = 0;
	static int delayedNBound = 0;
	static int SuthernBound = 0;
	static int delayedSBound = 0;
	static char n = 'N';
	static char s = 'S';
    static Semaphore mutexR = new Semaphore(1);
    static Semaphore bridge = new Semaphore(1);
    
    
    //TrafficLight creates the N amount of NorthCar processes and S amount of SouthCar processes
    public static void main(String [] args) {
    	
    	Random random = new Random();
		int countS = random.nextInt(5) + 1;
		int countN = random.nextInt(5) + 1;

	    
	    //Cars roughRider = new Cars(99,'X'); roughRider.start();
	    //System.out.println(bridge);
		for(int i = 0; i< countN; i++) {
	    	Cars vroom = new Cars(i, n);
	    	vroom.start();
	    }
		
		for(int j = 0; j< countS; j++) {
	    	
	    	Cars vroom = new Cars(j,s);
	    	vroom.start();    
	    }
	    
	    /*
	     * Sem s1 = new Sem(0);
	     * Sem s2 = new Sem(0);
	     * Sem s3 = new Sem(0);
	     * int p5 = 0;
	     * process pOne(){
	     * 
	     * 		Sem successor = s1;	// initializing sems in successor as needed in each process
	     * 
	     * 		//This process is first in precedence so it need not check for predecessors
	     * 		
	     * 		** Do Work**;
	     * 
	     * 		V(succesor[i]);
	     * 			
	     * 			
	     * 		
	     * }
	     * 
	     * process pTwo(){
	     * 		Sem predecessor = s1;
	     * 		Sem successor = s2;	
	     * 		
	     * 		P(predecessor[i]);		//After this is true, the processes need to release the sem so they
	     * 		V(predecessor[i]; 	//don't delay any other processes who have the same predecessor
	     * 
	     * 			
	     * 
	     * 		
	     * 		** Do Work**;
	     * 
	     * 		V(succesor[i]);
	     * 			
	     * 			
	     * 		
	     * }
	     * 
	     * process pThree(){
	     * 		Sem predecessor = s1;
	     * 		Sem successor = s3;	
	     * 		
	     * 		P(predecessor[i]);		
	     * 		V(predecessor[i]; 	
	     * 
	     * 			
	     * 
	     * 		
	     * 		** Do Work**;
	     * 
	     *
	     * 		//This part is particular to pThree and pFour as pFive requires both to be done
	     * 		p5++;
	     * 		while(p5 < 2) skip;
	     * 		V(succesor[i]);
	     *
	     * 			
	     * 	
	     * }
	     * 
	     * process pFour(){
	     * 		Sem predecessor = s1;
	     * 		Sem successor = s3;	
	     * 		
	     * 
	     * 		P(predecessor[i]);		
	     * 		V(predecessor[i]; 	
	     * 	
	     * 			
	     * 
	     * 		
	     * 		** Do Work**;
	     * 
	     *
	     * 		//This part is particular to pThree and pFour as pFive requires both to be done
	     * 		p5++;
	     * 		while(p5 < 2) skip;
	     * 		V(succesor);
	     * 
	     * 			
	     * 
	     * }
	     * 
	     * process pFive(){
	     * 		Sem predecessor = s3;
	     *	
	     * 		
	     * 		P(predecessor);		
	     * 		V(predecessor; 	
	     * 			
	     * 			
	     * 		
	     * 		
	     * 		** Do Work**;
	     * 
	     * 		//Last process so no successors
	     * }
	     */
    }
}
