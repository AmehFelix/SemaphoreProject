package no5;

import java.util.concurrent.Semaphore;
import java.util.Random;


public class Cars extends Thread{
	private int id = 0;
	private char bound = 'X';
	private String start = " : Destination: Knowhere, ETA: Who:Cares PM, Objective: Burn it alll@!%^...";
	
	public Cars(int i, char x) { 
		
		this.id = i; 
		this.bound = x;
		if(x == TrafficLight.n)
			start =  ": Northern bound";
		else if(x == TrafficLight.s)
			start = ": heading South";
	}
	
	private void waka() {
		
		Random random = new Random();
		int randNum = random.nextInt(5) + 1;
		System.out.println("\nHello, this is Process "+ bound + id + start + " ETA: " + randNum + "min(s)");
		for(int i =0; i <randNum; i++) {
			System.out.print("P" + bound + id + " : ");
			try{ sleep(500); } catch (InterruptedException e) { } ;
		}
		System.out.println("\nProcess " + bound + id + " exiting the bridge; Safe travels");
		
	}

	private void addNorthernCar() {
		
		P(TrafficLight.mutexR);
		
		TrafficLight.NorthernBound++;
			if (TrafficLight.NorthernBound == 1) {
				P(TrafficLight.bridge);
			}
			
			
        V(TrafficLight.mutexR);
        //V(TrafficLight.mutexR);
        waka();
        //System.out.print("mutexR=" + TrafficLight.mutexR);
        P(TrafficLight.mutexR); 
        
        	TrafficLight.NorthernBound--;
        	if (TrafficLight.NorthernBound == 0) {
        		V(TrafficLight.bridge);
        	}
        	
        V(TrafficLight.mutexR);

        try{ sleep(1000) ; } catch (InterruptedException e) { } ;
	}
	
	private void addSuthernCar() {
		
		P(TrafficLight.mutexR);
		
			TrafficLight.SuthernBound++;
			if (TrafficLight.SuthernBound == 1) {
				P(TrafficLight.bridge);
			}
			TrafficLight.SuthernBound++;
		V(TrafficLight.mutexR);
		//System.out.print("Hello");
    	waka();
    
    	P(TrafficLight.mutexR); 
    
    		TrafficLight.SuthernBound--;
    		if (TrafficLight.SuthernBound == 0) V(TrafficLight.bridge);
    	
    	V(TrafficLight.mutexR);

    	try{ sleep(1000) ; } catch (InterruptedException e) { } ;
	}

	public void run(){
		
		switch (bound) {
			case 'N' -> {
				addNorthernCar();
			}
			case 'S' -> {
				
				addSuthernCar();
			}
			default -> {
				System.out.println("Process "+ bound + id + start);
				System.err.println("%$$$...<<Control Regained>> Looks like Process " + bound + id +
									 " ran amok a bit. Remember to assign all processes a destination");
			}
		}

	}
	
	
	void P(Semaphore s) {
		//System.out.print("Hello, this is P ");
        try {
            s.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    void V(Semaphore s) {
    	System.out.print("Hello, this is V ");
        s.release();
        System.out.print(s);
    }
	
}
